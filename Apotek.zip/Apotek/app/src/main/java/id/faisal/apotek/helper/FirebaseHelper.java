package id.faisal.apotek.helper;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FirebaseHelper {

    private static final String DB_URL =
            "https://apotek-faisal-default-rtdb.asia-southeast1.firebasedatabase.app/";

    public static DatabaseReference dbUser() {

        return FirebaseDatabase
                .getInstance(DB_URL)
                .getReference("users");
    }

    public static DatabaseReference dbObat() {

        return FirebaseDatabase
                .getInstance(DB_URL)
                .getReference("obat");
    }

    public static DatabaseReference dbTransaksi() {

        return FirebaseDatabase
                .getInstance(DB_URL)
                .getReference("transaksi");
    }
}