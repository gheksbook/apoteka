package id.faisal.apotek.helper;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    public SessionManager(Context context) {

        sharedPreferences =
                context.getSharedPreferences(
                        "LOGIN",
                        Context.MODE_PRIVATE);

        editor = sharedPreferences.edit();
    }

    public void saveSession(
            String uid,
            String nama,
            String role) {

        editor.putBoolean("is_login", true);

        editor.putString("uid", uid);

        editor.putString("nama", nama);

        editor.putString("role", role);

        editor.apply();
    }

    public String getUid() {

        return sharedPreferences
                .getString("uid", "");
    }

    public String getNama() {

        return sharedPreferences
                .getString("nama", "");
    }

    public String getRole() {

        return sharedPreferences
                .getString("role", "");
    }

    public boolean isLogin() {

        return sharedPreferences
                .getBoolean("is_login", false);
    }

    public void logout() {

        editor.clear();

        editor.apply();
    }
}