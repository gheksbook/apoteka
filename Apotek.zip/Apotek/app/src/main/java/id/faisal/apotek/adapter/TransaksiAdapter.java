    package id.faisal.apotek.adapter;

    public class TransaksiAdapter {
    }
