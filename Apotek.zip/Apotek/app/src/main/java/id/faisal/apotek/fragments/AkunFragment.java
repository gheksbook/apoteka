package id.faisal.apotek.fragments;

import static android.app.Activity.RESULT_OK;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import id.faisal.apotek.R;
import id.faisal.apotek.activities.LoginActivity;
import id.faisal.apotek.databinding.DialogEditNamaBinding;
import id.faisal.apotek.databinding.FragmentAkunBinding;
import id.faisal.apotek.helper.FirebaseHelper;
import id.faisal.apotek.helper.SessionManager;

public class AkunFragment extends Fragment {

    private FragmentAkunBinding binding;

    private SharedPreferences sharedPref;

    private SessionManager sessionManager;

    private String uid;

    // GALERI
    private final ActivityResultLauncher<Intent> galleryLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),

                    result -> {

                        if (result.getResultCode() == RESULT_OK
                                &&
                                result.getData() != null) {

                            Uri selectedImageUri =
                                    result.getData().getData();

                            if (selectedImageUri != null) {

                                binding.ivProfileLarge
                                        .setImageURI(selectedImageUri);

                                savePhotoUri(
                                        selectedImageUri.toString());

                                Toast.makeText(
                                        getContext(),
                                        "Foto Profil Diperbarui",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                    });

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        binding =
                FragmentAkunBinding.inflate(
                        inflater,
                        container,
                        false);

        sessionManager =
                new SessionManager(getContext());

        uid =
                sessionManager.getUid();

        sharedPref =
                requireActivity()
                        .getSharedPreferences(
                                "ApotekPrefs",
                                Context.MODE_PRIVATE);

        // PROTEKSI UID NULL
        if (uid == null || uid.isEmpty()) {

            Toast.makeText(
                    getContext(),
                    "Session login tidak ditemukan",
                    Toast.LENGTH_LONG
            ).show();

            startActivity(
                    new Intent(
                            getActivity(),
                            LoginActivity.class));

            requireActivity().finish();

            return binding.getRoot();
        }

        loadUserData();

        loadSavedPhoto();

        binding.btnUbahProfil
                .setOnClickListener(v ->
                        showEditNameBottomSheet());

        binding.btnLogout
                .setOnClickListener(v ->
                        showLogoutDialog());

        binding.btnEditPhoto
                .setOnClickListener(v ->
                        showPhotoOptions());

        return binding.getRoot();
    }

    private void showPhotoOptions() {

        BottomSheetDialog optionsSheet =
                new BottomSheetDialog(requireContext());

        View view =
                getLayoutInflater()
                        .inflate(
                                R.layout.dialog_photo_options,
                                null);

        optionsSheet.setContentView(view);

        // GALERI
        view.findViewById(R.id.optionGallery)
                .setOnClickListener(v -> {

                    Intent intent =
                            new Intent(
                                    Intent.ACTION_PICK,
                                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                    galleryLauncher.launch(intent);

                    optionsSheet.dismiss();
                });

        // HAPUS FOTO
        view.findViewById(R.id.optionRemove)
                .setOnClickListener(v -> {

                    binding.ivProfileLarge
                            .setImageResource(R.drawable.ic_person);

                    savePhotoUri(null);

                    optionsSheet.dismiss();

                    Toast.makeText(
                            getContext(),
                            "Foto profil dihapus",
                            Toast.LENGTH_SHORT
                    ).show();
                });

        optionsSheet.show();
    }

    private void savePhotoUri(String uriString) {

        sharedPref.edit()
                .putString("photo_" + uid, uriString)
                .apply();
    }

    private void loadSavedPhoto() {

        String uriStr =
                sharedPref.getString(
                        "photo_" + uid,
                        null);

        if (uriStr != null) {

            try {

                binding.ivProfileLarge
                        .setImageURI(Uri.parse(uriStr));

            } catch (Exception e) {

                binding.ivProfileLarge
                        .setImageResource(R.drawable.ic_person);
            }
        }
    }
    private void loadUserData() {
        FirebaseHelper.dbUser()
                .child(uid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists() && binding != null) {
                            String nama = snapshot.child("nama").getValue(String.class);
                            String email = snapshot.child("email").getValue(String.class);
                            String role = snapshot.child("role").getValue(String.class);

                            // Set Nama Besar
                            binding.tvNamaBesar.setText(nama);

                            // Set Email di Card
                            binding.tvEmailUser.setText(email);

                            // Set Role di Card
                            binding.tvRoleUser.setText(role != null ? role.toUpperCase() : "STAFF");

                            // --- TAMBAHKAN KODE DI BAWAH INI ---
                            // Ini untuk mengubah badge "ADMIN ONLINE" menjadi "KASIR ONLINE" dsb.
                            if (role != null) {
                                binding.tvStatusBadge.setText(role.toUpperCase() + " ONLINE");
                            }
                            // -----------------------------------
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void showEditNameBottomSheet() {

        BottomSheetDialog bottomSheet =
                new BottomSheetDialog(
                        requireContext(),
                        R.style.BottomSheetDialogTheme);

        DialogEditNamaBinding dBinding =
                DialogEditNamaBinding.inflate(
                        getLayoutInflater());

        bottomSheet.setContentView(
                dBinding.getRoot());

        dBinding.etNewName
                .setText(
                        binding.tvNamaBesar
                                .getText()
                                .toString());

        dBinding.btnSaveName
                .setOnClickListener(v -> {

                    String name =
                            dBinding.etNewName
                                    .getText()
                                    .toString()
                                    .trim();

                    if (name.isEmpty()) return;

                    FirebaseHelper.dbUser()
                            .child(uid)
                            .child("nama")
                            .setValue(name)

                            .addOnSuccessListener(a -> {

                                Toast.makeText(
                                        getContext(),
                                        "Nama berhasil diubah",
                                        Toast.LENGTH_SHORT
                                ).show();

                                bottomSheet.dismiss();
                            });
                });

        bottomSheet.show();
    }

    private void showLogoutDialog() {

        new AlertDialog.Builder(requireContext())

                .setTitle("Konfirmasi")

                .setMessage("Keluar dari aplikasi?")

                .setPositiveButton(
                        "Logout",
                        (d, w) -> {

                            sessionManager.logout();

                            startActivity(
                                    new Intent(
                                            getActivity(),
                                            LoginActivity.class));

                            requireActivity().finish();
                        })

                .setNegativeButton(
                        "Batal",
                        null)

                .show();
    }

    @Override
    public void onDestroyView() {

        super.onDestroyView();

        binding = null;
    }
}