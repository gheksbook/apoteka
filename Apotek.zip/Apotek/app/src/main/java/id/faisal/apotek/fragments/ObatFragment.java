package id.faisal.apotek.fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import id.faisal.apotek.helper.SessionManager;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import id.faisal.apotek.adapter.ObatAdapter;
import id.faisal.apotek.databinding.DialogTambahObatBinding;
import id.faisal.apotek.databinding.FragmentObatBinding;
import id.faisal.apotek.helper.FirebaseHelper;
import id.faisal.apotek.model.Obat;

public class ObatFragment extends Fragment {

    private FragmentObatBinding binding;

    private ObatAdapter adapter;

    private final List<Obat> listObat =
            new ArrayList<>();

    private Uri imageUri;

    private DialogTambahObatBinding dialogBinding;
    private SessionManager sessionManager;

    private String role;
    // =========================
    // PICK IMAGE
    // =========================
    private final ActivityResultLauncher<Intent> pickImage =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),

                    result -> {

                        if (result.getResultCode()
                                == Activity.RESULT_OK
                                &&
                                result.getData() != null) {

                            imageUri =
                                    result.getData().getData();

                            try {

                                requireContext()
                                        .getContentResolver()
                                        .takePersistableUriPermission(
                                                imageUri,
                                                Intent.FLAG_GRANT_READ_URI_PERMISSION
                                        );

                            } catch (Exception ignored) {
                            }

                            if (dialogBinding != null) {

                                dialogBinding.ivFotoObat
                                        .setImageURI(imageUri);

                                dialogBinding.layoutPlaceholder
                                        .setVisibility(View.GONE);
                            }
                        }
                    });

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {

        binding =
                FragmentObatBinding.inflate(
                        inflater,
                        container,
                        false
                );
        sessionManager =
                new SessionManager(getContext());

        role =
                sessionManager.getRole();
        setupRecyclerView();

        loadDataObat();

        // =========================
        // SEARCH
        // =========================
        binding.etSearch.addTextChangedListener(
                new TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count) {

                        if (adapter != null) {

                            adapter.filter(
                                    s.toString()
                            );
                        }
                    }

                    @Override
                    public void afterTextChanged(
                            Editable s) {
                    }
                });

        // =========================
        // TAMBAH OBAT
        // =========================
        binding.fabAddObat
                .setOnClickListener(v ->
                        showAddObatDialog());
        if (role.equals("kasir")) {

            binding.fabAddObat
                    .setVisibility(View.GONE);
        }
        return binding.getRoot();
    }

    // =========================
    // SETUP RECYCLER VIEW
    // =========================
    private void setupRecyclerView() {

        adapter =
                new ObatAdapter(
                        listObat,
                        role
                );

        GridLayoutManager gridLayoutManager =
                new GridLayoutManager(
                        getContext(),
                        2
                );

        binding.rvObat
                .setLayoutManager(gridLayoutManager);

        binding.rvObat
                .setHasFixedSize(true);

        binding.rvObat
                .setAdapter(adapter);
    }

    // =========================
    // DIALOG TAMBAH OBAT
    // =========================
    private void showAddObatDialog() {

        dialogBinding =
                DialogTambahObatBinding.inflate(
                        getLayoutInflater()
                );

        imageUri = null;

        AlertDialog dialog =
                new AlertDialog.Builder(
                        getContext()
                )
                        .setView(
                                dialogBinding.getRoot()
                        )
                        .create();

        // =========================
        // DROPDOWN KATEGORI
        // =========================
        String[] kategori = {
                "Tablet",
                "Sirup",
                "Kapsul",
                "Salep",
                "Injeksi",
                "Lainnya"
        };

        ArrayAdapter<String> arrayAdapter =
                new ArrayAdapter<>(
                        requireContext(),
                        android.R.layout.simple_list_item_1,
                        kategori
                );

        dialogBinding.spinnerKategori
                .setAdapter(arrayAdapter);

        // =========================
        // DATE PICKER
        // =========================
        dialogBinding.etTglKadaluarsa
                .setOnClickListener(v -> {

                    Calendar c =
                            Calendar.getInstance();

                    new DatePickerDialog(
                            getContext(),

                            (view, year, month, dayOfMonth) -> {

                                String date =
                                        dayOfMonth
                                                + "/"
                                                + (month + 1)
                                                + "/"
                                                + year;

                                dialogBinding.etTglKadaluarsa
                                        .setText(date);
                            },

                            c.get(Calendar.YEAR),
                            c.get(Calendar.MONTH),
                            c.get(Calendar.DAY_OF_MONTH)
                    ).show();
                });

        // =========================
        // PILIH FOTO
        // =========================
        dialogBinding.cardPilihFoto
                .setOnClickListener(v -> {

                    Intent intent =
                            new Intent(
                                    Intent.ACTION_PICK,
                                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                            );

                    pickImage.launch(intent);
                });

        // =========================
        // SIMPAN OBAT
        // =========================
        dialogBinding.btnSimpanObat
                .setOnClickListener(v -> {

                    String nama =
                            dialogBinding.etNamaObat
                                    .getText()
                                    .toString()
                                    .trim();

                    String harga =
                            dialogBinding.etHargaObat
                                    .getText()
                                    .toString()
                                    .trim();

                    String stok =
                            dialogBinding.etStokObat
                                    .getText()
                                    .toString()
                                    .trim();

                    String kategoriObat =
                            dialogBinding.spinnerKategori
                                    .getText()
                                    .toString()
                                    .trim();

                    String tanggal =
                            dialogBinding.etTglKadaluarsa
                                    .getText()
                                    .toString()
                                    .trim();

                    // =========================
                    // VALIDASI
                    // =========================
                    if (nama.isEmpty()
                            || harga.isEmpty()
                            || stok.isEmpty()
                            || kategoriObat.isEmpty()
                            || tanggal.isEmpty()
                            || imageUri == null) {

                        Toast.makeText(
                                getContext(),
                                "Harap lengkapi semua data!",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }

                    // =========================
                    // ID OBAT
                    // =========================
                    String id =
                            FirebaseHelper.dbObat()
                                    .push()
                                    .getKey();

                    if (id == null) {

                        Toast.makeText(
                                getContext(),
                                "Gagal membuat ID obat",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }

                    // =========================
                    // OBJECT OBAT
                    // =========================
                    Obat obat =
                            new Obat(
                                    id,
                                    nama,
                                    harga,
                                    stok,
                                    imageUri.toString(),
                                    kategoriObat,
                                    tanggal
                            );

                    // =========================
                    // SIMPAN FIREBASE
                    // =========================
                    FirebaseHelper.dbObat()
                            .child(id)
                            .setValue(obat)

                            .addOnSuccessListener(unused -> {

                                Toast.makeText(
                                        getContext(),
                                        "Obat berhasil ditambahkan",
                                        Toast.LENGTH_SHORT
                                ).show();

                                dialog.dismiss();

                                imageUri = null;
                            })

                            .addOnFailureListener(e -> {

                                Toast.makeText(
                                        getContext(),
                                        e.getMessage(),
                                        Toast.LENGTH_LONG
                                ).show();
                            });
                });

        dialog.show();
    }

    // =========================
    // LOAD DATA OBAT
    // =========================
    private void loadDataObat() {

        FirebaseHelper.dbObat()
                .addValueEventListener(
                        new ValueEventListener() {

                            @Override
                            public void onDataChange(
                                    @NonNull DataSnapshot snapshot) {

                                if (binding == null)
                                    return;

                                List<Obat> tempList =
                                        new ArrayList<>();

                                for (DataSnapshot s :
                                        snapshot.getChildren()) {

                                    Obat obat =
                                            s.getValue(
                                                    Obat.class
                                            );

                                    if (obat != null) {

                                        // PASTIKAN ID TERISI
                                        obat.setId(
                                                s.getKey()
                                        );

                                        tempList.add(obat);
                                    }
                                }

                                listObat.clear();

                                listObat.addAll(tempList);

                                adapter.updateList(tempList);
                            }

                            @Override
                            public void onCancelled(
                                    @NonNull DatabaseError error) {

                                Toast.makeText(
                                        getContext(),
                                        error.getMessage(),
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        });
    }

    @Override
    public void onDestroyView() {

        super.onDestroyView();

        binding = null;
    }
}