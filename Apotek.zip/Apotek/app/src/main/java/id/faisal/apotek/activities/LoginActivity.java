package id.faisal.apotek.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import id.faisal.apotek.databinding.ActivityLoginBinding;
import id.faisal.apotek.helper.FirebaseHelper;
import id.faisal.apotek.helper.SessionManager;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;

    private ProgressDialog loading;

    private DatabaseReference databaseReference;

    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding =
                ActivityLoginBinding.inflate(
                        getLayoutInflater());

        setContentView(binding.getRoot());

        sessionManager =
                new SessionManager(this);

        // AUTO LOGIN
        if (sessionManager.isLogin()) {

            startActivity(
                    new Intent(
                            LoginActivity.this,
                            MainActivity.class));

            finish();

            return;
        }

        loading = new ProgressDialog(this);
        loading.setMessage("Mencoba Masuk...");

        databaseReference =
                FirebaseHelper.dbUser();

        binding.btnLogin.setOnClickListener(v -> {

            String email =
                    binding.etEmailLogin
                            .getText()
                            .toString()
                            .trim();

            String pass =
                    binding.etPasswordLogin
                            .getText()
                            .toString()
                            .trim();

            if (email.isEmpty()) {

                binding.etEmailLogin
                        .setError("Email wajib diisi");

                return;
            }

            if (pass.isEmpty()) {

                binding.etPasswordLogin
                        .setError("Password wajib diisi");

                return;
            }

            prosesLogin(email, pass);

        });
    }

    private void prosesLogin(
            String email,
            String pass) {

        loading.show();

        databaseReference
                .addListenerForSingleValueEvent(
                        new ValueEventListener() {

                            @Override
                            public void onDataChange(
                                    @NonNull DataSnapshot snapshot) {

                                loading.dismiss();

                                boolean loginBerhasil = false;

                                for (DataSnapshot data :
                                        snapshot.getChildren()) {

                                    // AMBIL UID DARI KEY FIREBASE
                                    String uid =
                                            data.getKey();

                                    String dbEmail =
                                            data.child("email")
                                                    .getValue(String.class);

                                    String dbPass =
                                            data.child("password")
                                                    .getValue(String.class);

                                    String role =
                                            data.child("role")
                                                    .getValue(String.class);

                                    String nama =
                                            data.child("nama")
                                                    .getValue(String.class);

                                    if (dbEmail == null
                                            || dbPass == null) {

                                        continue;
                                    }

                                    if (email.equals(dbEmail)
                                            &&
                                            pass.equals(dbPass)) {

                                        loginBerhasil = true;

                                        // SIMPAN SESSION
                                        sessionManager.saveSession(
                                                uid,
                                                nama,
                                                role
                                        );

                                        Toast.makeText(
                                                LoginActivity.this,
                                                "Selamat Datang " + nama,
                                                Toast.LENGTH_SHORT
                                        ).show();

                                        Intent intent =
                                                new Intent(
                                                        LoginActivity.this,
                                                        MainActivity.class);

                                        intent.putExtra(
                                                "uid",
                                                uid);

                                        intent.putExtra(
                                                "nama",
                                                nama);

                                        intent.putExtra(
                                                "role",
                                                role);

                                        startActivity(intent);

                                        finish();

                                        break;
                                    }
                                }

                                if (!loginBerhasil) {

                                    Toast.makeText(
                                            LoginActivity.this,
                                            "Email atau Password salah",
                                            Toast.LENGTH_SHORT
                                    ).show();
                                }
                            }

                            @Override
                            public void onCancelled(
                                    @NonNull DatabaseError error) {

                                loading.dismiss();

                                Toast.makeText(
                                        LoginActivity.this,
                                        error.getMessage(),
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        });
    }
}