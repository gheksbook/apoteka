package id.faisal.apotek.fragments;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import id.faisal.apotek.R;
import id.faisal.apotek.databinding.FragmentTransaksiBinding;
import id.faisal.apotek.helper.FirebaseHelper;
import id.faisal.apotek.helper.SessionManager;
import id.faisal.apotek.model.Obat;
import id.faisal.apotek.model.Transaksi;

public class TransaksiFragment extends Fragment {

    private FragmentTransaksiBinding binding;

    private final ArrayList<Obat> listObat =
            new ArrayList<>();

    private final ArrayList<String> namaObatList =
            new ArrayList<>();

    private SessionManager sessionManager;

    private Obat selectedObat;

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        binding =
                FragmentTransaksiBinding.inflate(
                        inflater,
                        container,
                        false
                );

        sessionManager =
                new SessionManager(getContext());

        // =========================
        // LOAD DATA OBAT
        // =========================
        loadObat();

        // =========================
        // LISTENER JUMLAH
        // =========================
        binding.etJumlah
                .addTextChangedListener(
                        new TextWatcher() {

                            @Override
                            public void beforeTextChanged(
                                    CharSequence s,
                                    int start,
                                    int count,
                                    int after) {

                            }

                            @Override
                            public void onTextChanged(
                                    CharSequence s,
                                    int start,
                                    int before,
                                    int count) {

                                hitungTotal();
                            }

                            @Override
                            public void afterTextChanged(
                                    Editable s) {

                            }
                        });

        // =========================
        // PILIH OBAT
        // =========================
        binding.acNamaObat
                .setOnItemClickListener(
                        (parent, view, position, id) -> {

                            selectedObat =
                                    listObat.get(position);

                            hitungTotal();
                        });

        // =========================
        // BUTTON SIMPAN
        // =========================
        binding.btnSimpanTransaksi
                .setOnClickListener(v ->
                        simpanTransaksi());

        // =========================
        // BUTTON RIWAYAT
        // =========================
        binding.btnRiwayat
                .setOnClickListener(v -> {

                    requireActivity()
                            .getSupportFragmentManager()
                            .beginTransaction()
                            .replace(
                                    R.id.fragment_container,
                                    new RiwayatFragment()
                            )
                            .addToBackStack(null)
                            .commit();
                });

        return binding.getRoot();
    }

    // =========================
    // LOAD OBAT
    // =========================
    private void loadObat() {

        FirebaseHelper.dbObat()
                .addListenerForSingleValueEvent(
                        new ValueEventListener() {

                            @Override
                            public void onDataChange(
                                    @NonNull DataSnapshot snapshot) {

                                listObat.clear();

                                namaObatList.clear();

                                for (DataSnapshot s :
                                        snapshot.getChildren()) {

                                    Obat obat =
                                            s.getValue(
                                                    Obat.class
                                            );

                                    if (obat != null) {

                                        obat.setId(
                                                s.getKey()
                                        );

                                        listObat.add(obat);

                                        namaObatList.add(
                                                obat.getNamaObat()
                                        );
                                    }
                                }

                                ArrayAdapter<String> adapter =
                                        new ArrayAdapter<>(
                                                requireContext(),
                                                android.R.layout.simple_list_item_1,
                                                namaObatList
                                        );

                                binding.acNamaObat
                                        .setAdapter(adapter);
                            }

                            @Override
                            public void onCancelled(
                                    @NonNull DatabaseError error) {

                            }
                        });
    }

    // =========================
    // HITUNG TOTAL
    // =========================
    private void hitungTotal() {

        // VALIDASI OBAT
        if (selectedObat == null) {

            binding.tvTotalHarga
                    .setText("Rp 0");

            return;
        }

        // AMBIL JUMLAH
        String jumlahText =
                binding.etJumlah
                        .getText()
                        .toString()
                        .trim();

        // VALIDASI KOSONG
        if (jumlahText.isEmpty()) {

            binding.tvTotalHarga
                    .setText("Rp 0");

            return;
        }

        try {

            int jumlah =
                    Integer.parseInt(
                            jumlahText
                    );

            int harga =
                    Integer.parseInt(
                            selectedObat.getHarga()
                    );

            int total =
                    jumlah * harga;

            // FORMAT RUPIAH
            binding.tvTotalHarga
                    .setText(
                            "Rp " +
                                    String.format("%,d", total)
                    );

        } catch (Exception e) {

            e.printStackTrace();

            binding.tvTotalHarga
                    .setText("Rp 0");
        }
    }

    // =========================
    // SIMPAN TRANSAKSI
    // =========================
    private void simpanTransaksi() {

        // VALIDASI OBAT
        if (selectedObat == null) {

            Toast.makeText(
                    getContext(),
                    "Pilih obat dulu",
                    Toast.LENGTH_SHORT
            ).show();

            binding.tvTotalHarga
                    .setText("Rp 0");

            return;
        }

        // VALIDASI JUMLAH
        String jumlahText =
                binding.etJumlah
                        .getText()
                        .toString()
                        .trim();

        if (jumlahText.isEmpty()) {

            Toast.makeText(
                    getContext(),
                    "Jumlah wajib diisi",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        try {

            int jumlah =
                    Integer.parseInt(
                            jumlahText
                    );

            int stok =
                    Integer.parseInt(
                            selectedObat.getStok()
                    );

            int harga =
                    Integer.parseInt(
                            selectedObat.getHarga()
                    );

            // VALIDASI STOK
            if (jumlah > stok) {

                Toast.makeText(
                        getContext(),
                        "Stok tidak cukup",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            int total =
                    jumlah * harga;

            // GENERATE ID
            String id =
                    FirebaseHelper.dbTransaksi()
                            .push()
                            .getKey();

            // FORMAT TANGGAL
            String tanggal =
                    new SimpleDateFormat(
                            "dd/MM/yyyy HH:mm",
                            Locale.getDefault()
                    ).format(new Date());

            // OBJECT TRANSAKSI
            Transaksi transaksi =
                    new Transaksi(
                            id,
                            sessionManager.getUid(),
                            sessionManager.getNama(),
                            selectedObat.getNamaObat(),
                            jumlah,
                            harga,
                            total,
                            tanggal
                    );

            // SIMPAN FIREBASE
            FirebaseHelper.dbTransaksi()
                    .child(id)
                    .setValue(transaksi)

                    .addOnSuccessListener(unused -> {

                        // KURANGI STOK
                        int sisaStok =
                                stok - jumlah;

                        FirebaseHelper.dbObat()
                                .child(selectedObat.getId())
                                .child("stok")
                                .setValue(
                                        String.valueOf(
                                                sisaStok
                                        )
                                );

                        Toast.makeText(
                                getContext(),
                                "Transaksi berhasil",
                                Toast.LENGTH_SHORT
                        ).show();

                        // RESET FORM
                        binding.acNamaObat
                                .setText("");

                        binding.etJumlah
                                .setText("");

                        binding.tvTotalHarga
                                .setText("Rp 0");

                        selectedObat = null;
                    })

                    .addOnFailureListener(e -> {

                        Toast.makeText(
                                getContext(),
                                e.getMessage(),
                                Toast.LENGTH_LONG
                        ).show();
                    });

        } catch (Exception e) {

            e.printStackTrace();

            Toast.makeText(
                    getContext(),
                    "Terjadi kesalahan input",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    @Override
    public void onDestroyView() {

        super.onDestroyView();

        binding = null;
    }
}