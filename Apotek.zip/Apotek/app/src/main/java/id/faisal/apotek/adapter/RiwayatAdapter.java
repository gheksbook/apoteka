package id.faisal.apotek.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import id.faisal.apotek.databinding.ItemRiwayatBinding;
import id.faisal.apotek.model.Transaksi;

public class RiwayatAdapter
        extends RecyclerView.Adapter<RiwayatAdapter.ViewHolder> {

    private final List<Transaksi> list;

    public RiwayatAdapter(List<Transaksi> list) {

        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType) {

        ItemRiwayatBinding binding =
                ItemRiwayatBinding.inflate(
                        LayoutInflater.from(parent.getContext()),
                        parent,
                        false
                );

        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(
            @NonNull ViewHolder holder,
            int position) {

        Transaksi transaksi =
                list.get(position);

        holder.binding.tvNamaObat
                .setText(transaksi.getNamaObat());

        holder.binding.tvJumlah
                .setText(
                        "Jumlah : " +
                                transaksi.getJumlah()
                );

        holder.binding.tvTotal
                .setText(
                        "Rp " +
                                transaksi.getTotalHarga()
                );

        holder.binding.tvTanggal
                .setText(
                        transaksi.getTanggal()
                );

        holder.binding.tvKasir
                .setText(
                        "Kasir : " +
                                transaksi.getNamaKasir()
                );
    }

    @Override
    public int getItemCount() {

        return list.size();
    }

    public static class ViewHolder
            extends RecyclerView.ViewHolder {

        ItemRiwayatBinding binding;

        public ViewHolder(
                ItemRiwayatBinding binding) {

            super(binding.getRoot());

            this.binding = binding;
        }
    }
}