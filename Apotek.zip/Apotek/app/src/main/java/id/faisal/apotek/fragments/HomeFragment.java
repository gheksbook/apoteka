package id.faisal.apotek.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import id.faisal.apotek.R;
import id.faisal.apotek.databinding.FragmentHomeBinding;
import id.faisal.apotek.helper.FirebaseHelper;
import id.faisal.apotek.helper.SessionManager;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    private SessionManager sessionManager;

    private String role;

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {

        binding =
                FragmentHomeBinding.inflate(
                        inflater,
                        container,
                        false
                );

        sessionManager =
                new SessionManager(
                        requireContext()
                );

        role =
                sessionManager.getRole();

        // =========================
        // SETUP
        // =========================
        setupUIByRole();

        getStats();

        setupQuickAction();

        return binding.getRoot();
    }

    // =========================
    // UI BERDASARKAN ROLE
    // =========================
    private void setupUIByRole() {

        if (binding == null)
            return;

        String nama =
                sessionManager.getNama();

        binding.tvWelcome
                .setText(
                        "Halo, " +
                                (nama != null
                                        ? nama
                                        : "User")
                );

        binding.tvRole
                .setText(
                        role.toUpperCase()
                );

        // =========================
        // ROLE ADMIN
        // =========================
        if (role.equalsIgnoreCase("admin")) {

            binding.tvMotto
                    .setText(
                            "Panel Kontrol Administrator Apotek"
                    );

            binding.layoutMenuKasir
                    .setVisibility(View.GONE);

            binding.layoutMenuAdmin
                    .setVisibility(View.VISIBLE);

            binding.cardTotalKasir
                    .setVisibility(View.VISIBLE);

            binding.tvRole
                    .setBackgroundColor(
                            Color.parseColor("#3730A3")
                    );

        }

        // =========================
        // ROLE KASIR
        // =========================
        else {

            binding.tvMotto
                    .setText(
                            "Melayani dengan sepenuh hati ✨"
                    );

            binding.layoutMenuKasir
                    .setVisibility(View.VISIBLE);

            binding.layoutMenuAdmin
                    .setVisibility(View.GONE);

            binding.cardTotalKasir
                    .setVisibility(View.GONE);

            binding.tvRole
                    .setBackgroundColor(
                            Color.parseColor("#059669")
                    );
        }
    }

    // =========================
    // QUICK ACTION
    // =========================
    private void setupQuickAction() {

        // =========================
        // MENU KASIR
        // =========================
        binding.cardQuickTransaksi
                .setOnClickListener(v -> {

                    requireActivity()
                            .getSupportFragmentManager()
                            .beginTransaction()
                            .replace(
                                    R.id.fragment_container,
                                    new TransaksiFragment()
                            )
                            .addToBackStack(null)
                            .commit();
                });

        // =========================
        // MENU ADMIN
        // =========================

        // KE INVENTARIS / OBAT
        binding.btnKelolaObat
                .setOnClickListener(v -> {

                    requireActivity()
                            .getSupportFragmentManager()
                            .beginTransaction()
                            .replace(
                                    R.id.fragment_container,
                                    new ObatFragment()
                            )
                            .addToBackStack(null)
                            .commit();
                });

        // KE LAPORAN / RIWAYAT
        binding.btnLaporan
                .setOnClickListener(v -> {

                    requireActivity()
                            .getSupportFragmentManager()
                            .beginTransaction()
                            .replace(
                                    R.id.fragment_container,
                                    new RiwayatFragment()
                            )
                            .addToBackStack(null)
                            .commit();
                });

        // KE KELOLA KASIR
        binding.btnKelolaKasir
                .setOnClickListener(v -> {

                    requireActivity()
                            .getSupportFragmentManager()
                            .beginTransaction()
                            .replace(
                                    R.id.fragment_container,
                                    new KasirFragment()
                            )
                            .addToBackStack(null)
                            .commit();
                });
    }

    // =========================
    // AMBIL STATISTIK
    // =========================
    private void getStats() {

        // =========================
        // TOTAL OBAT
        // =========================
        FirebaseHelper.dbObat()
                .addValueEventListener(
                        new ValueEventListener() {

                            @Override
                            public void onDataChange(
                                    @NonNull DataSnapshot snapshot) {

                                if (binding == null)
                                    return;

                                binding.tvTotalObat
                                        .setText(
                                                String.valueOf(
                                                        snapshot.getChildrenCount()
                                                )
                                        );

                                int warningCount = 0;

                                for (DataSnapshot s :
                                        snapshot.getChildren()) {

                                    Object stokObj =
                                            s.child("stok")
                                                    .getValue();

                                    if (stokObj != null) {

                                        try {

                                            int stok =
                                                    Integer.parseInt(
                                                            stokObj.toString()
                                                    );

                                            if (stok < 5) {

                                                warningCount++;
                                            }

                                        } catch (Exception ignored) {
                                        }
                                    }
                                }

                                updateWarningCard(
                                        warningCount
                                );
                            }

                            @Override
                            public void onCancelled(
                                    @NonNull DatabaseError error) {

                            }
                        });

        // =========================
        // TOTAL TRANSAKSI
        // =========================
        FirebaseHelper.dbTransaksi()
                .addValueEventListener(
                        new ValueEventListener() {

                            @Override
                            public void onDataChange(
                                    @NonNull DataSnapshot snapshot) {

                                if (binding == null)
                                    return;

                                binding.tvTransaksiHariIni
                                        .setText(
                                                String.valueOf(
                                                        snapshot.getChildrenCount()
                                                )
                                        );
                            }

                            @Override
                            public void onCancelled(
                                    @NonNull DatabaseError error) {

                            }
                        });

        // =========================
        // TOTAL KASIR
        // =========================
        if (role.equalsIgnoreCase("admin")) {

            FirebaseHelper.dbUser()
                    .addValueEventListener(
                            new ValueEventListener() {

                                @Override
                                public void onDataChange(
                                        @NonNull DataSnapshot snapshot) {

                                    int totalKasir = 0;

                                    for (DataSnapshot s :
                                            snapshot.getChildren()) {

                                        String r =
                                                s.child("role")
                                                        .getValue(
                                                                String.class
                                                        );

                                        if (r != null
                                                &&
                                                r.equalsIgnoreCase(
                                                        "kasir")) {

                                            totalKasir++;
                                        }
                                    }

                                    if (binding != null) {

                                        binding.tvTotalKasir
                                                .setText(
                                                        String.valueOf(
                                                                totalKasir
                                                        )
                                                );
                                    }
                                }

                                @Override
                                public void onCancelled(
                                        @NonNull DatabaseError error) {

                                }
                            });
        }
    }

    // =========================
    // WARNING CARD
    // =========================
    private void updateWarningCard(
            int count) {

        if (count > 0) {

            // =========================
            // WARNING MERAH
            // =========================
            binding.cardWarning
                    .setStrokeColor(
                            Color.parseColor("#FECACA")
                    );

            binding.cardWarning
                    .getChildAt(0)
                    .setBackgroundColor(
                            Color.parseColor("#FEF2F2")
                    );

            binding.tvStokWarning
                    .setText(
                            count +
                                    " Obat Menipis!"
                    );

            binding.tvStokWarning
                    .setTextColor(
                            Color.parseColor("#DC2626")
                    );

            binding.tvStokDesc
                    .setText(
                            "Segera lakukan restock barang ke supplier."
                    );

            binding.ivAlertIcon
                    .setImageResource(
                            android.R.drawable.stat_sys_warning
                    );

            binding.ivAlertIcon
                    .setColorFilter(
                            Color.parseColor("#DC2626")
                    );

        } else {

            // =========================
            // WARNING HIJAU
            // =========================
            binding.cardWarning
                    .setStrokeColor(
                            Color.parseColor("#BBF7D0")
                    );

            binding.cardWarning
                    .getChildAt(0)
                    .setBackgroundColor(
                            Color.parseColor("#F0FDF4")
                    );

            binding.tvStokWarning
                    .setText(
                            "Semua Stok Aman"
                    );

            binding.tvStokWarning
                    .setTextColor(
                            Color.parseColor("#16A34A")
                    );

            binding.tvStokDesc
                    .setText(
                            "Persediaan di gudang saat ini mencukupi."
                    );

            binding.ivAlertIcon
                    .setImageResource(
                            android.R.drawable.ic_dialog_info
                    );

            binding.ivAlertIcon
                    .setColorFilter(
                            Color.parseColor("#16A34A")
                    );
        }
    }

    @Override
    public void onDestroyView() {

        super.onDestroyView();

        binding = null;
    }
}