package id.faisal.apotek.fragments;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import androidx.appcompat.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;

import id.faisal.apotek.adapter.RiwayatAdapter;
import id.faisal.apotek.databinding.FragmentRiwayatBinding;
import id.faisal.apotek.helper.FirebaseHelper;
import id.faisal.apotek.helper.SessionManager;
import id.faisal.apotek.model.Transaksi;

public class RiwayatFragment extends Fragment {

    private FragmentRiwayatBinding binding;

    // Gunakan dua list: satu untuk data master (semua), satu untuk ditampilkan (hasil filter)
    private final ArrayList<Transaksi> masterList = new ArrayList<>();
    private final ArrayList<Transaksi> displayList = new ArrayList<>();

    private RiwayatAdapter adapter;
    private SessionManager sessionManager;
    private String role;
    private String selectedDate = ""; // Untuk menyimpan filter tanggal aktif

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        binding = FragmentRiwayatBinding.inflate(inflater, container, false);
        sessionManager = new SessionManager(getContext());
        role = sessionManager.getRole();

        // Pass displayList ke adapter
        adapter = new RiwayatAdapter(displayList);
        binding.rvRiwayat.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.rvRiwayat.setAdapter(adapter);

        loadRiwayat();
        setupSearchAndFilter();

        return binding.getRoot();
    }

    private void loadRiwayat() {
        FirebaseHelper.dbTransaksi().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                masterList.clear();

                for (DataSnapshot s : snapshot.getChildren()) {
                    Transaksi transaksi = s.getValue(Transaksi.class);

                    if (transaksi != null) {
                        // ADMIN LIHAT SEMUA
                        if (role.equals("admin")) {
                            masterList.add(transaksi);
                        }
                        // KASIR HANYA MILIKNYA
                        else {
                            if (transaksi.getIdKasir() != null &&
                                    transaksi.getIdKasir().equals(sessionManager.getUid())) {
                                masterList.add(transaksi);
                            }
                        }
                    }
                }

                // Setel awal tampilan agar memuat semua data master
                filterData(binding.searchView.getQuery().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    private void setupSearchAndFilter() {
        // Fitur Pencarian
        binding.searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterData(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterData(newText);
                return true;
            }
        });

        // Fitur Filter Tanggal
        binding.btnFilterTanggal.setOnClickListener(v -> showDatePicker());
    }

    private void filterData(String query) {
        displayList.clear();
        String lowerCaseQuery = query.toLowerCase();

        for (Transaksi transaksi : masterList) {
            // Asumsi: Model transaksi memiliki method getNamaObat() dan getTanggal()
            // Sesuaikan pemanggilan method dengan struktur Model Transaksi Anda
            boolean matchesSearch = false;

            // Cek pencarian teks (bisa tambah pengecekan kasir dsb.)
            if (transaksi.getNamaObat() != null && transaksi.getNamaObat().toLowerCase().contains(lowerCaseQuery)) {
                matchesSearch = true;
            }

            // Cek filter tanggal
            boolean matchesDate = true;
            if (!selectedDate.isEmpty()) {
                // Pastikan format string tanggal di database cocok dengan selectedDate
                // Contoh: transaksi.getTanggal() is "12-10-2023"
                if (transaksi.getTanggal() != null && !transaksi.getTanggal().contains(selectedDate)) {
                    matchesDate = false;
                }
            }

            // Jika lolos kedua filter, tambahkan ke layar
            if ((matchesSearch || lowerCaseQuery.isEmpty()) && matchesDate) {
                displayList.add(transaksi);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(),
                (view, year1, monthOfYear, dayOfMonth) -> {
                    // Format tanggal harus disesuaikan dengan yang disimpan di Firebase
                    // Contoh jika di firebase "dd-MM-yyyy":
                    String formattedMonth = (monthOfYear + 1 < 10) ? "0" + (monthOfYear + 1) : String.valueOf(monthOfYear + 1);
                    String formattedDay = (dayOfMonth < 10) ? "0" + dayOfMonth : String.valueOf(dayOfMonth);

                    selectedDate = formattedDay + "-" + formattedMonth + "-" + year1; // Sesuaikan format Anda

                    // Trigger filter lagi
                    filterData(binding.searchView.getQuery().toString());
                }, year, month, day);

        // Opsional: Tambahkan tombol untuk mereset filter
        datePickerDialog.setButton(DatePickerDialog.BUTTON_NEUTRAL, "Clear Filter", (dialog, which) -> {
            selectedDate = "";
            filterData(binding.searchView.getQuery().toString());
        });

        datePickerDialog.show();
    }
}