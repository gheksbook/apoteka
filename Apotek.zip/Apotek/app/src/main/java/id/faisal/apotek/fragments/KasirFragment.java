package id.faisal.apotek.fragments;

import androidx.appcompat.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import id.faisal.apotek.R;
import id.faisal.apotek.adapter.KasirAdapter;
import id.faisal.apotek.helper.FirebaseHelper;
import id.faisal.apotek.model.User;

public class KasirFragment extends Fragment {

    private RecyclerView recyclerKasir;

    private FloatingActionButton fabTambah;

    private LinearLayout emptyLayout;

    private EditText etSearch;

    private List<User> list;

    private KasirAdapter adapter;

    private DatabaseReference databaseReference;

    public KasirFragment() {

    }

    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {

        View view =
                inflater.inflate(
                        R.layout.fragment_kasir,
                        container,
                        false
                );

        // =========================
        // INIT VIEW
        // =========================
        recyclerKasir =
                view.findViewById(
                        R.id.recyclerKasir
                );

        fabTambah =
                view.findViewById(
                        R.id.fabTambah
                );

        emptyLayout =
                view.findViewById(
                        R.id.emptyLayout
                );

        etSearch =
                view.findViewById(
                        R.id.etSearch
                );

        // =========================
        // DATABASE
        // =========================
        databaseReference =
                FirebaseHelper.dbUser();

        // =========================
        // LIST
        // =========================
        list = new ArrayList<>();

        // =========================
        // RECYCLER VIEW
        // =========================
        recyclerKasir.setLayoutManager(
                new GridLayoutManager(
                        getContext(),
                        2
                )
        );

        recyclerKasir.setHasFixedSize(true);

        // =========================
        // ADAPTER
        // =========================
        adapter =
                new KasirAdapter(
                        getContext(),
                        list
                );

        recyclerKasir.setAdapter(adapter);

        // =========================
        // LOAD DATA
        // =========================
        loadKasir();

        // =========================
        // SEARCH
        // =========================
        etSearch.addTextChangedListener(
                new TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after) {

                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count) {

                        if (adapter != null) {

                            adapter.filter(
                                    s.toString()
                            );
                        }
                    }

                    @Override
                    public void afterTextChanged(
                            Editable s) {

                    }
                });

        // =========================
        // TAMBAH KASIR
        // =========================
        fabTambah.setOnClickListener(v -> {

            showDialogTambah();

        });

        return view;
    }

    // =========================
    // LOAD DATA KASIR
    // =========================
    private void loadKasir() {

        databaseReference
                .addValueEventListener(
                        new ValueEventListener() {

                            @Override
                            public void onDataChange(
                                    @NonNull DataSnapshot snapshot) {

                                list.clear();

                                for (DataSnapshot data :
                                        snapshot.getChildren()) {

                                    User user =
                                            data.getValue(
                                                    User.class
                                            );

                                    if (user != null) {

                                        // UID DARI KEY FIREBASE
                                        user.setUid(
                                                data.getKey()
                                        );

                                        // FILTER ROLE KASIR
                                        if (user.getRole() != null
                                                &&
                                                user.getRole()
                                                        .equalsIgnoreCase(
                                                                "kasir"
                                                        )) {

                                            list.add(user);
                                        }
                                    }
                                }
                                adapter.updateList(new ArrayList<>(list));

                                checkEmptyState();
                            }

                            @Override
                            public void onCancelled(
                                    @NonNull DatabaseError error) {

                                if (getContext() != null) {

                                    Toast.makeText(
                                            getContext(),
                                            error.getMessage(),
                                            Toast.LENGTH_SHORT
                                    ).show();
                                }
                            }
                        });
    }

    // =========================
    // EMPTY STATE
    // =========================
    private void checkEmptyState() {

        if (list.isEmpty()) {

            recyclerKasir
                    .setVisibility(View.GONE);

            emptyLayout
                    .setVisibility(View.VISIBLE);

        } else {

            recyclerKasir
                    .setVisibility(View.VISIBLE);

            emptyLayout
                    .setVisibility(View.GONE);
        }
    }

    // =========================
    // DIALOG TAMBAH
    // =========================
    private void showDialogTambah() {

        View dialogView =
                LayoutInflater
                        .from(getContext())
                        .inflate(
                                R.layout.dialog_tambah_kasir,
                                null
                        );

        EditText etNama = dialogView.findViewById(R.id.etNama);
        EditText etEmail = dialogView.findViewById(R.id.etEmail);
        EditText etPassword = dialogView.findViewById(R.id.etPassword);
        Button btnSimpan = dialogView.findViewById(R.id.btnSimpan);

        AlertDialog.Builder builder =
                new AlertDialog.Builder(requireContext());

        builder.setView(dialogView);

        AlertDialog dialog = builder.create();

// BACKGROUND TRANSPARAN
        if (dialog.getWindow() != null) {

            dialog.getWindow().setBackgroundDrawableResource(
                    android.R.color.transparent
            );
        }

        dialog.show();

        btnSimpan.setOnClickListener(v -> {
            // ... (SEMUA LOGIKA VALIDASI & SIMPAN FIREBASE TETAP 100% SAMA)
            String nama = etNama.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (nama.isEmpty()) {
                etNama.setError("Nama wajib diisi");
                etNama.requestFocus();
                return;
            }
            if (email.isEmpty()) {
                etEmail.setError("Email wajib diisi");
                etEmail.requestFocus();
                return;
            }
            if (password.isEmpty()) {
                etPassword.setError("Password wajib diisi");
                etPassword.requestFocus();
                return;
            }

            tambahKasir(nama, email, password, dialog);
        });
    }

    // =========================
    // TAMBAH KASIR
    // =========================
    private void tambahKasir(
            String nama,
            String email,
            String password,
            AlertDialog dialog) {

        // UID DARI FIREBASE KEY
        String uid =
                databaseReference
                        .push()
                        .getKey();

        if (uid == null)
            return;

        // =========================
        // DATA USER
        // =========================
        HashMap<String, Object> map =
                new HashMap<>();

        // JANGAN SIMPAN UID
        // KARENA LOGIN PAKAI FIREBASE KEY

        map.put("nama", nama);

        map.put("email", email);

        map.put("password", password);

        map.put("role", "kasir");

        // =========================
        // SIMPAN FIREBASE
        // =========================
        databaseReference
                .child(uid)
                .setValue(map)

                .addOnSuccessListener(unused -> {

                    if (getContext() != null) {

                        Toast.makeText(
                                getContext(),
                                "Kasir berhasil ditambahkan",
                                Toast.LENGTH_SHORT
                        ).show();
                    }

                    dialog.dismiss();
                })

                .addOnFailureListener(e -> {

                    if (getContext() != null) {

                        Toast.makeText(
                                getContext(),
                                e.getMessage(),
                                Toast.LENGTH_LONG
                        ).show();
                    }
                });
    }
}