package id.faisal.apotek.model;

public class User {

    private String uid;
    private String nama;
    private String email;
    private String password;
    private String role;

    public User() {

    }

    public User(String uid,
                String nama,
                String email,
                String password,
                String role) {

        this.uid = uid;
        this.nama = nama;
        this.email = email;
        this.password = password;
        this.role = role;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}