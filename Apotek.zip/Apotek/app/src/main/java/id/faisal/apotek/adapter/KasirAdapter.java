package id.faisal.apotek.adapter;
import com.google.android.material.button.MaterialButton;
import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import id.faisal.apotek.R;
import id.faisal.apotek.helper.FirebaseHelper;
import id.faisal.apotek.model.User;

public class KasirAdapter
        extends RecyclerView.Adapter<KasirAdapter.ViewHolder> {

    private final Context context;

    // LIST TAMPILAN
    private List<User> list;

    // LIST ASLI UNTUK SEARCH
    private final List<User> fullList;

    public KasirAdapter(
            Context context,
            List<User> list) {

        this.context = context;

        // PENTING
        // JANGAN REFERENCE LANGSUNG
        this.list = new ArrayList<>();

        this.fullList = new ArrayList<>();

        updateList(list);
    }

    // =========================
    // UPDATE LIST
    // =========================
    public void updateList(
            List<User> newList) {

        // LIST BARU
        this.list = new ArrayList<>(newList);

        // FULL LIST
        fullList.clear();

        fullList.addAll(newList);

        notifyDataSetChanged();
    }

    // =========================
    // FILTER SEARCH
    // =========================
    public void filter(String text) {

        List<User> filteredList =
                new ArrayList<>();

        if (text == null
                || text.trim().isEmpty()) {

            filteredList.addAll(fullList);

        } else {

            text =
                    text.toLowerCase().trim();

            for (User user : fullList) {

                String nama =
                        user.getNama() != null
                                ? user.getNama()
                                .toLowerCase()
                                : "";

                String email =
                        user.getEmail() != null
                                ? user.getEmail()
                                .toLowerCase()
                                : "";

                if (nama.contains(text)
                        || email.contains(text)) {

                    filteredList.add(user);
                }
            }
        }

        // GANTI LIST
        list = filteredList;

        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType) {

        View view =
                LayoutInflater
                        .from(context)
                        .inflate(
                                R.layout.item_kasir,
                                parent,
                                false
                        );

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull ViewHolder holder,
            int position) {

        // PENGAMAN
        if (position >= list.size()) {
            return;
        }

        User user = list.get(position);

        // =========================
        // NAMA
        // =========================
        holder.tvNama.setText(
                user.getNama() != null
                        ? user.getNama()
                        : "-"
        );

        // =========================
        // EMAIL
        // =========================
        holder.tvEmail.setText(
                user.getEmail() != null
                        ? user.getEmail()
                        : "-"
        );

        // =========================
        // ROLE
        // =========================
        holder.tvRole.setText(
                user.getRole() != null
                        ? user.getRole()
                        : "-"
        );

        // =========================
        // INITIAL
        // =========================
        if (user.getNama() != null
                &&
                !user.getNama().isEmpty()) {

            holder.tvInitial.setText(
                    user.getNama()
                            .substring(0, 1)
                            .toUpperCase()
            );

        } else {

            holder.tvInitial.setText("?");
        }

        // =========================
        // EDIT
        // =========================
        holder.btnEdit.setOnClickListener(v -> {

            AlertDialog.Builder builder =
                    new AlertDialog.Builder(
                            context
                    );

            builder.setTitle("Edit Kasir");

            LinearLayout layout =
                    new LinearLayout(context);

            layout.setOrientation(
                    LinearLayout.VERTICAL
            );

            layout.setPadding(
                    50,
                    30,
                    50,
                    10
            );

            // INPUT NAMA
            EditText etNama =
                    new EditText(context);

            etNama.setHint("Nama");

            etNama.setText(
                    user.getNama()
            );

            layout.addView(etNama);

            // INPUT EMAIL
            EditText etEmail =
                    new EditText(context);

            etEmail.setHint("Email");

            etEmail.setInputType(
                    InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            );

            etEmail.setText(
                    user.getEmail()
            );

            layout.addView(etEmail);

            builder.setView(layout);

            // UPDATE
            builder.setPositiveButton(
                    "Update",
                    (dialog, which) -> {

                        String nama =
                                etNama.getText()
                                        .toString()
                                        .trim();

                        String email =
                                etEmail.getText()
                                        .toString()
                                        .trim();

                        if (nama.isEmpty()) {

                            Toast.makeText(
                                    context,
                                    "Nama wajib diisi",
                                    Toast.LENGTH_SHORT
                            ).show();

                            return;
                        }

                        if (email.isEmpty()) {

                            Toast.makeText(
                                    context,
                                    "Email wajib diisi",
                                    Toast.LENGTH_SHORT
                            ).show();

                            return;
                        }

                        HashMap<String, Object> map =
                                new HashMap<>();

                        map.put("nama", nama);

                        map.put("email", email);

                        FirebaseHelper.dbUser()
                                .child(user.getUid())
                                .updateChildren(map)

                                .addOnSuccessListener(unused -> {

                                    Toast.makeText(
                                            context,
                                            "Kasir berhasil diupdate",
                                            Toast.LENGTH_SHORT
                                    ).show();

                                    // UPDATE LOCAL
                                    user.setNama(nama);

                                    user.setEmail(email);

                                    notifyDataSetChanged();
                                })

                                .addOnFailureListener(e -> {

                                    Toast.makeText(
                                            context,
                                            e.getMessage(),
                                            Toast.LENGTH_LONG
                                    ).show();
                                });
                    });

            builder.setNegativeButton(
                    "Batal",
                    null
            );

            builder.show();
        });

        // =========================
        // HAPUS
        // =========================
        holder.btnHapus.setOnClickListener(v -> {

            new AlertDialog.Builder(context)

                    .setTitle("Hapus Kasir")

                    .setMessage(
                            "Yakin ingin menghapus kasir ini?"
                    )

                    .setPositiveButton(
                            "Ya",
                            (dialog, which) -> {

                                FirebaseHelper.dbUser()
                                        .child(user.getUid())
                                        .removeValue()

                                        .addOnSuccessListener(unused -> {

                                            Toast.makeText(
                                                    context,
                                                    "Kasir berhasil dihapus",
                                                    Toast.LENGTH_SHORT
                                            ).show();

                                            // HAPUS DARI LIST
                                            list.remove(user);

                                            fullList.remove(user);

                                            notifyDataSetChanged();
                                        })

                                        .addOnFailureListener(e -> {

                                            Toast.makeText(
                                                    context,
                                                    e.getMessage(),
                                                    Toast.LENGTH_LONG
                                            ).show();
                                        });
                            })

                    .setNegativeButton(
                            "Batal",
                            null)

                    .show();
        });
    }

    @Override
    public int getItemCount() {

        return list != null
                ? list.size()
                : 0;
    }

    // =========================
    // VIEW HOLDER
    // =========================
    public static class ViewHolder
            extends RecyclerView.ViewHolder {

        TextView tvNama,
                tvEmail,
                tvRole,
                tvInitial;

        MaterialButton btnEdit,
                btnHapus;

        public ViewHolder(
                @NonNull View itemView) {

            super(itemView);

            tvNama =
                    itemView.findViewById(
                            R.id.tvNama
                    );

            tvEmail =
                    itemView.findViewById(
                            R.id.tvEmail
                    );

            tvRole =
                    itemView.findViewById(
                            R.id.tvRole
                    );

            tvInitial =
                    itemView.findViewById(
                            R.id.tvInitial
                    );

            btnEdit =
                    itemView.findViewById(
                            R.id.btnEdit
                    );

            btnHapus =
                    itemView.findViewById(
                            R.id.btnHapus
                    );
        }
    }
}