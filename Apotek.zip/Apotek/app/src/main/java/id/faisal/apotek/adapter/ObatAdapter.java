package id.faisal.apotek.adapter;

import android.app.AlertDialog;
import android.net.Uri;
import android.text.InputType;
import android.view.LayoutInflater;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Toast;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import id.faisal.apotek.R;
import id.faisal.apotek.databinding.ItemObatBinding;
import id.faisal.apotek.helper.FirebaseHelper;
import id.faisal.apotek.model.Obat;

public class ObatAdapter
        extends RecyclerView.Adapter<ObatAdapter.ObatViewHolder> {

    private final List<Obat> obatList;

    private final List<Obat> fullList;
    private final String role;
    public ObatAdapter(
            List<Obat> obatList,
            String role) {

        this.obatList = obatList;

        this.role = role;

        this.fullList = new ArrayList<>();
    }

    // =========================
    // UPDATE LIST
    // =========================
    public void updateList(List<Obat> newList) {

        obatList.clear();
        obatList.addAll(newList);

        fullList.clear();
        fullList.addAll(newList);

        notifyDataSetChanged();
    }

    // =========================
    // SEARCH FILTER
    // =========================
    public void filter(String text) {

        obatList.clear();

        if (text == null || text.trim().isEmpty()) {

            obatList.addAll(fullList);

        } else {

            String keyword =
                    text.toLowerCase().trim();

            for (Obat obat : fullList) {

                if (obat.getNamaObat() != null
                        &&
                        obat.getNamaObat()
                                .toLowerCase()
                                .contains(keyword)) {

                    obatList.add(obat);
                }
            }
        }

        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ObatViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType) {

        ItemObatBinding binding =
                ItemObatBinding.inflate(
                        LayoutInflater.from(parent.getContext()),
                        parent,
                        false
                );

        return new ObatViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(
            @NonNull ObatViewHolder holder,
            int position) {

        Obat obat = obatList.get(position);

        // =========================
        // DATA
        // =========================
        holder.binding.tvNamaObat
                .setText(obat.getNamaObat());

        holder.binding.tvHargaObat
                .setText("Rp " + obat.getHarga());

        holder.binding.tvStokObat
                .setText("Stok: " + obat.getStok());

        holder.binding.tvKategoriBadge
                .setText(obat.getKategori());

        holder.binding.tvKadaluarsa
                .setText(
                        "Exp: " +
                                obat.getTglKadaluarsa()
                );

        // =========================
        // FOTO
        // =========================
        if (obat.getFotoUrl() != null
                &&
                !obat.getFotoUrl().isEmpty()) {

            Glide.with(holder.itemView.getContext())
                    .load(Uri.parse(obat.getFotoUrl()))
                    .placeholder(R.drawable.ic_medication)
                    .into(holder.binding.ivItemObat);

        } else {

            holder.binding.ivItemObat
                    .setImageResource(
                            R.drawable.ic_medication
                    );
        }
        if (role.equals("kasir")) {

            holder.binding.btnMenuObat
                    .setVisibility(View.GONE);

        } else {

            holder.binding.btnMenuObat
                    .setVisibility(View.VISIBLE);
        }
        // =========================
        // MENU TITIK 3
        // =========================
        holder.binding.btnMenuObat
                .setOnClickListener(v -> {

                    PopupMenu popupMenu =
                            new PopupMenu(
                                    holder.itemView.getContext(),
                                    holder.binding.btnMenuObat
                            );

                    popupMenu.getMenu().add("Edit");

                    popupMenu.getMenu().add("Hapus");

                    popupMenu.setOnMenuItemClickListener(item -> {

                        if (item.getTitle()
                                .equals("Edit")) {

                            showEditDialog(holder, obat);

                        } else {

                            hapusObat(holder, obat);
                        }

                        return true;
                    });

                    popupMenu.show();
                });
    }

    // =========================
    // EDIT
    // =========================
    private void showEditDialog(
            ObatViewHolder holder,
            Obat obat) {

        AlertDialog.Builder builder =
                new AlertDialog.Builder(
                        holder.itemView.getContext()
                );

        builder.setTitle("Edit Obat");

        LinearLayout layout =
                new LinearLayout(
                        holder.itemView.getContext()
                );

        layout.setOrientation(
                LinearLayout.VERTICAL
        );

        layout.setPadding(
                50,
                30,
                50,
                10
        );

        // =========================
        // NAMA
        // =========================
        EditText etNama =
                new EditText(
                        holder.itemView.getContext()
                );

        etNama.setHint("Nama Obat");

        etNama.setText(
                obat.getNamaObat()
        );

        layout.addView(etNama);

        // =========================
        // HARGA
        // =========================
        EditText etHarga =
                new EditText(
                        holder.itemView.getContext()
                );

        etHarga.setHint("Harga");

        etHarga.setInputType(
                InputType.TYPE_CLASS_NUMBER
        );

        etHarga.setText(
                obat.getHarga()
        );

        layout.addView(etHarga);

        // =========================
        // STOK
        // =========================
        EditText etStok =
                new EditText(
                        holder.itemView.getContext()
                );

        etStok.setHint("Stok");

        etStok.setInputType(
                InputType.TYPE_CLASS_NUMBER
        );

        etStok.setText(
                obat.getStok()
        );

        layout.addView(etStok);

        builder.setView(layout);

        // =========================
        // UPDATE
        // =========================
        builder.setPositiveButton(
                "Update",
                (dialog, which) -> {

                    String nama =
                            etNama.getText()
                                    .toString()
                                    .trim();

                    String harga =
                            etHarga.getText()
                                    .toString()
                                    .trim();

                    String stok =
                            etStok.getText()
                                    .toString()
                                    .trim();

                    if (nama.isEmpty()
                            || harga.isEmpty()
                            || stok.isEmpty()) {

                        Toast.makeText(
                                holder.itemView.getContext(),
                                "Semua field wajib diisi",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }

                    HashMap<String, Object> map =
                            new HashMap<>();

                    map.put("namaObat", nama);

                    map.put("harga", harga);

                    map.put("stok", stok);

                    FirebaseHelper.dbObat()
                            .child(obat.getId())
                            .updateChildren(map)

                            .addOnSuccessListener(unused -> {

                                Toast.makeText(
                                        holder.itemView.getContext(),
                                        "Obat berhasil diupdate",
                                        Toast.LENGTH_SHORT
                                ).show();

                                // UPDATE LOCAL
                                obat.setNamaObat(nama);
                                obat.setHarga(harga);
                                obat.setStok(stok);

                                notifyDataSetChanged();
                            })

                            .addOnFailureListener(e -> {

                                Toast.makeText(
                                        holder.itemView.getContext(),
                                        e.getMessage(),
                                        Toast.LENGTH_LONG
                                ).show();
                            });
                });

        builder.setNegativeButton(
                "Batal",
                null
        );

        builder.show();
    }

    // =========================
    // HAPUS
    // =========================
    private void hapusObat(
            ObatViewHolder holder,
            Obat obat) {

        new AlertDialog.Builder(
                holder.itemView.getContext()
        )

                .setTitle("Hapus Obat")

                .setMessage(
                        "Yakin ingin menghapus obat ini?"
                )

                .setPositiveButton(
                        "Ya",
                        (dialog, which) -> {

                            FirebaseHelper.dbObat()
                                    .child(obat.getId())
                                    .removeValue()

                                    .addOnSuccessListener(unused -> {

                                        Toast.makeText(
                                                holder.itemView.getContext(),
                                                "Obat berhasil dihapus",
                                                Toast.LENGTH_SHORT
                                        ).show();

                                        // HAPUS DARI LIST LOCAL
                                        obatList.remove(obat);

                                        fullList.remove(obat);

                                        notifyDataSetChanged();
                                    })

                                    .addOnFailureListener(e -> {

                                        Toast.makeText(
                                                holder.itemView.getContext(),
                                                e.getMessage(),
                                                Toast.LENGTH_LONG
                                        ).show();
                                    });
                        })

                .setNegativeButton(
                        "Batal",
                        null)

                .show();
    }

    @Override
    public int getItemCount() {

        return obatList.size();
    }

    // =========================
    // VIEW HOLDER
    // =========================
    public static class ObatViewHolder
            extends RecyclerView.ViewHolder {

        ItemObatBinding binding;

        public ObatViewHolder(
                ItemObatBinding binding) {

            super(binding.getRoot());

            this.binding = binding;
        }
    }
}