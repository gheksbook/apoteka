package id.faisal.apotek.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import id.faisal.apotek.R;
import id.faisal.apotek.databinding.ActivityMainBinding;
import id.faisal.apotek.fragments.AkunFragment;
import id.faisal.apotek.fragments.HomeFragment;
import id.faisal.apotek.fragments.KasirFragment;
import id.faisal.apotek.fragments.ObatFragment;
import id.faisal.apotek.fragments.RiwayatFragment;
import id.faisal.apotek.fragments.TransaksiFragment;
import id.faisal.apotek.helper.SessionManager;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    private SessionManager sessionManager;

    private String role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        binding =
                ActivityMainBinding.inflate(
                        getLayoutInflater()
                );

        setContentView(binding.getRoot());
        binding.bottomNavigation
                .setItemIconTintList(null);

        // =========================
        // SESSION
        // =========================
        sessionManager =
                new SessionManager(this);

        role =
                sessionManager.getRole();

        // =========================
        // ROLE KASIR
        // =========================
        if (role.equals("kasir")) {

            // SEMBUNYIKAN MENU KASIR
            binding.bottomNavigation
                    .getMenu()
                    .findItem(R.id.nav_kasir)
                    .setVisible(false);
        }

        // =========================
        // FRAGMENT PERTAMA
        // =========================
        loadFragment(new HomeFragment());

        // =========================
        // BOTTOM NAVIGATION
        // =========================
        binding.bottomNavigation
                .setOnItemSelectedListener(item -> {

                    Fragment selectedFragment = null;

                    int id = item.getItemId();

                    // =========================
                    // HOME
                    // =========================
                    if (id == R.id.nav_home) {

                        selectedFragment =
                                new HomeFragment();
                    }

                    // =========================
                    // OBAT
                    // =========================
                    else if (id == R.id.nav_obat) {

                        selectedFragment =
                                new ObatFragment();
                    }

                    // =========================
                    // TRANSAKSI / RIWAYAT
                    // =========================
                    else if (id == R.id.nav_transaksi) {

                        // ROLE KASIR
                        if (role.equals("kasir")) {

                            selectedFragment =
                                    new TransaksiFragment();
                        }

                        // ROLE ADMIN
                        else if (role.equals("admin")) {

                            selectedFragment =
                                    new RiwayatFragment();
                        }
                    }

                    // =========================
                    // KELOLA KASIR
                    // =========================
                    else if (id == R.id.nav_kasir) {

                        // HANYA ADMIN
                        if (role.equals("admin")) {

                            selectedFragment =
                                    new KasirFragment();
                        }
                    }

                    // =========================
                    // AKUN
                    // =========================
                    else if (id == R.id.nav_akun) {

                        selectedFragment =
                                new AkunFragment();
                    }

                    return loadFragment(selectedFragment);
                });
    }

    // =========================
    // LOAD FRAGMENT
    // =========================
    private boolean loadFragment(Fragment fragment) {

        if (fragment != null) {

            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(
                            R.id.fragment_container,
                            fragment
                    )
                    .commit();

            return true;
        }

        return false;
    }
}