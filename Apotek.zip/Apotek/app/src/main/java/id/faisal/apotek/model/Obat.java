package id.faisal.apotek.model;

public class Obat {

    private String id;
    private String namaObat;
    private String harga;
    private String stok;
    private String fotoUrl;
    private String kategori;
    private String tglKadaluarsa;

    // =========================
    // CONSTRUCTOR KOSONG
    // =========================
    public Obat() {
    }

    // =========================
    // CONSTRUCTOR
    // =========================
    public Obat(String id,
                String namaObat,
                String harga,
                String stok,
                String fotoUrl,
                String kategori,
                String tglKadaluarsa) {

        this.id = id;
        this.namaObat = namaObat;
        this.harga = harga;
        this.stok = stok;
        this.fotoUrl = fotoUrl;
        this.kategori = kategori;
        this.tglKadaluarsa = tglKadaluarsa;
    }

    // =========================
    // GETTER
    // =========================
    public String getId() {
        return id;
    }

    public String getNamaObat() {
        return namaObat;
    }

    public String getHarga() {
        return harga;
    }

    public String getStok() {
        return stok;
    }

    public String getFotoUrl() {
        return fotoUrl;
    }

    public String getKategori() {
        return kategori;
    }

    public String getTglKadaluarsa() {
        return tglKadaluarsa;
    }

    // =========================
    // SETTER
    // =========================
    public void setId(String id) {
        this.id = id;
    }

    public void setNamaObat(String namaObat) {
        this.namaObat = namaObat;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public void setStok(String stok) {
        this.stok = stok;
    }

    public void setFotoUrl(String fotoUrl) {
        this.fotoUrl = fotoUrl;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public void setTglKadaluarsa(String tglKadaluarsa) {
        this.tglKadaluarsa = tglKadaluarsa;
    }
}