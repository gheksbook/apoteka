package id.faisal.apotek.model;

public class Transaksi {

    private String idTransaksi;
    private String idKasir;
    private String namaKasir;

    private String namaObat;

    private int jumlah;

    private int harga;

    private int totalHarga;

    private String tanggal;

    public Transaksi() {
    }

    public Transaksi(
            String idTransaksi,
            String idKasir,
            String namaKasir,
            String namaObat,
            int jumlah,
            int harga,
            int totalHarga,
            String tanggal) {

        this.idTransaksi = idTransaksi;
        this.idKasir = idKasir;
        this.namaKasir = namaKasir;
        this.namaObat = namaObat;
        this.jumlah = jumlah;
        this.harga = harga;
        this.totalHarga = totalHarga;
        this.tanggal = tanggal;
    }

    public String getIdTransaksi() {
        return idTransaksi;
    }

    public void setIdTransaksi(String idTransaksi) {
        this.idTransaksi = idTransaksi;
    }

    public String getIdKasir() {
        return idKasir;
    }

    public void setIdKasir(String idKasir) {
        this.idKasir = idKasir;
    }

    public String getNamaKasir() {
        return namaKasir;
    }

    public void setNamaKasir(String namaKasir) {
        this.namaKasir = namaKasir;
    }

    public String getNamaObat() {
        return namaObat;
    }

    public void setNamaObat(String namaObat) {
        this.namaObat = namaObat;
    }

    public int getJumlah() {
        return jumlah;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    public int getTotalHarga() {
        return totalHarga;
    }

    public void setTotalHarga(int totalHarga) {
        this.totalHarga = totalHarga;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }
}